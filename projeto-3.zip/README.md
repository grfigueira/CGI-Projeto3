# CGI-Projeto3

Realistic light simulation in WebGL
